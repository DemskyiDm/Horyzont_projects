package p1;

public class A {
   public static int a1;
    public static String a2;

}
