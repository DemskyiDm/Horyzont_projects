package p1.p2.p3.p4;

import static p1.A.a1;
import static p1.p2.B.b1;
import static p1.p2.p3.C.c1;
import static p1.A.a2;


public class D {
    public static void main(String[] args) {
        System.out.println(a1);
        System.out.println(b1);
        System.out.println(c1);
        System.out.println(a2);
    }
}
