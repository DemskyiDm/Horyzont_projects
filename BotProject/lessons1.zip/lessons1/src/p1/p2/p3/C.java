package p1.p2.p3;

public class C {
    public static int c1;
    public static String c2;

}
