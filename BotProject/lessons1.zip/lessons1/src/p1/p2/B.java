package p1.p2;

public class B {
    public static int b1 = 8;
    public static String b2 = "23121";

}
