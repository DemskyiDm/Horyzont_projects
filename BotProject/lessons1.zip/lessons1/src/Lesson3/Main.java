package Lesson3;

public class Main {
    public static void main(String[] args) {

        int a = 5;
        int b = 8;
        int i1=5;
        int i2 = 11;
        double d1 = 5.5;
        double d2 = 1.3;
        long l =20L;
        double result = 0;
        result = i2/d1 + d2%i1-l; //2+1.3-20

        System.out.println(++b-b++ + ++b- --b); //9-9+11-10
    }
}

class test1 {
    public static void main(String[] args) {
    System.out.println ("ssss");
    }
    }
