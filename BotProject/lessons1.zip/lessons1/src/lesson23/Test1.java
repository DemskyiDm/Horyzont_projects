/*
package lesson23;

public class Test1 {
    public static void main(String[] args) {

        Doctor d = new Doctor();
        Teacher t = new Teacher();
        Driver dr = new Driver();
        Employee1 e = new Employee1();

        Employee1 emp1 = new Doctor();
        Employee1 emp2 = new Teacher1();
        Employee1 emp3 = new Driver();
        Employee1 emp4 = new Chirurg();
        Doctor d2 = new Chirurg();
        Chirurg ch = new Chirurg();

    }
}

class Employee1 {
    String name;
    int age;
    int experience;

    void eat() {
        System.out.println("eating");
    }

    void sleep() {
        System.out.println("sleeping");
    }
}

class Doctor extends Employee1 {
    void lechit() {
        System.out.println("leczit");
    }
}

class Chirurg extends Doctor {
    String skalpel;

    void operacja() {
    }
}

class Teacher1 extends Employee1 {
    int kol_voUch;

    void uchit() {
        System.out.println("uchit");
    }
}

class Driver extends Employee1 {
    String car;

    void vodit() {
        System.out.println("vodit");
    }
}*/
