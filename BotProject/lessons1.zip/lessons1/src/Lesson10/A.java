package Lesson10;


public class A {
    public static void main(String[] args) {
        int count = 2;
        System.out.println(Lesson9.Car.count);


    }
}
