package lesson15;

public class les106 {
    public static void main(String[] args) {
String s = "prvit";
        s = "hello";
        System.out.println(s);


    }
}
