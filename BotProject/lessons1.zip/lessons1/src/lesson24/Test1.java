package lesson24;

public class Test1 {
}

abstract class Kwadrat {
    int a = 6;

    abstract void abc();
}

class A extends Kwadrat {
    void abc() {
        System.out.println("sadas");
    }
}