package lesson14;

public class Test2 {
    public static void main(String[] args) {
        int i=1;
        for (; i < 3; i++) {
            System.out.println(i);
        }
        int a = i;

    }
}
