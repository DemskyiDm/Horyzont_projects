package lesson18;

public class Test5 {
    public static void main(String[] args) {
        int array1[] = {1, 9, 3, -8, 0, 5, 4, 1};
        int array2[] = {1, 9, 3, -8, 0, 5, 4, 1};
        System.out.println(array2 == array1);
        int array3[] = array2;
        int[] array5 = new int[2];


        System.out.println(array3.equals(array2));
    }
}
