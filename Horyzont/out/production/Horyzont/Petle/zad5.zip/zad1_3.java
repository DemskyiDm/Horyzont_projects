package Petle;

public class zad1_3 {
    public static void zad1() {
        for (int i = 1; i < 11; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void zad2() {
        for (int i = 5; i < 11; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void zad3() {
        for (int i = 10; i > 0; i--) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        zad1();
        zad2();
        zad3();

    }
}
