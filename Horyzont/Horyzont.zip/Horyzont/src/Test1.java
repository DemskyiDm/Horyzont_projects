
public class Test1 {
    public static void main(String[] args) {
        int n = 3;
        int i = 0;
        while (i < n) {
            System.out.print(i + " ");
            ++i;
        }
        int k = 3;
        int j = 0;
        System.out.println(" ");
        while (j < k) {
            System.out.print(j + " ");
            j++;
            }
        System.out.println(" ");
        for (int a = 0; a<k; ++a) {
            System.out.print(a);
        }
        System.out.println(" ");

        for (int b=0; ++b<k;) {
            System.out.print(b);
        }
        int a1 = 3;
      
    }
}
