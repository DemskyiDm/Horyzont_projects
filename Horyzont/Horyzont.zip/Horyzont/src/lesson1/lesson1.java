package lesson1;

import java.io.InputStream;
import java.util.Scanner;

public class lesson1 {
    public static void main(String[] args) {
        String tekst1 = "Java";
        String tekst2 = "Java1";
        System.out.println(tekst1.equals(tekst2));
        int a = 5;
        int b = 5;
        System.out.println(a==b);
        System.out.println(a==(b));

    }
}
