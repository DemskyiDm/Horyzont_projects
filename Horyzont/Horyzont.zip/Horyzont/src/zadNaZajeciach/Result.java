package zadNaZajeciach;

public class Result {
    public static void main(String[] args) {
        double a = 3.4;
        double b = 4.3;
        double c = a/b;
        System.out.printf("Wynik %.3f",c);
    }
}
