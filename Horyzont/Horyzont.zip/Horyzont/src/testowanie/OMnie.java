package testowanie;

public class OMnie {
    public static void main(String[] args) {
        String imie = "Dmytro";
        double height = 1.85;
        int weight = 70;
        System.out.printf("Mam na imie %s. Mam %.2f[m] wzrostu i %x[kg] wagi.%n", imie, height, weight);

    }
}
