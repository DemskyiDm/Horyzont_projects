package podstawy.zadanie5.obliczenia;

public class Wektor {
     final double dx = 5;
    final double dy = 3;

    public void zlozenie(double u, double v) {
        u += dx;
        v += dy;
    }

}
