package podstawy.zadanie5.obliczenia;

public class Figury {

}


