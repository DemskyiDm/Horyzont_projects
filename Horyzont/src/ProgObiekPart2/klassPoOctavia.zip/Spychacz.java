package ProgObiekPart2;

public class Spychacz extends Gasienicowe{
}
