package ProgObiekPart2;

public class Sedan extends Osobowy{
String model;
String symbol;
}
