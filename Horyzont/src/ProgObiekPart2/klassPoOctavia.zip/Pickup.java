package ProgObiekPart2;

public class Pickup extends Osobowy{

}
