package ProgObiekPart2;

public class SuperB extends Skoda{
}
