package ProgObiekPart2;

public class Szynowe extends Pojazd {

    public static void uruchomSilnik() {
        System.out.println("uruchomiono silnik pojazdu szynowego");
    }
}
