package ProgObiekPart2;public class klassPoOctavia {
}
