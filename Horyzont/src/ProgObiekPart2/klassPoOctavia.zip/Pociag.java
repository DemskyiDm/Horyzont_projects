package ProgObiekPart2;

public class Pociag extends Szynowe{
    String wlasciciel = "P.K.P.";

}
