package ProgObiekPart2;

public class VW extends Sedan{
    VW(int rokProdukcji, String rodzajSilnika, String kolor, int masa, String rozmiarOpony, int iloscOsob) {
        super();
    }
}
