package ProgObiekPart2;

public class Czolg extends Gasienicowe {
    public static void main(String[] args) {
        uruchomSilnik();

    }
}
