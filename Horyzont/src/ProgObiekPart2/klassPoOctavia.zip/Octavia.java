package ProgObiekPart2;

public final class Octavia extends Skoda{
}
