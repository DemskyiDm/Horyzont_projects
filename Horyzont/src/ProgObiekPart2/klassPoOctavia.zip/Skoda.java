package ProgObiekPart2;

public class Skoda extends Sedan{
}
